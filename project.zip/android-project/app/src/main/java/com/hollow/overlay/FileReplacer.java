package com.hollow.overlay;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileReplacer {

    /**
     * Safely replaces an active save file with a new file using atomic-like renaming.
     * Keeps a temp file to ensure that if write or delete fails, the file is not lost.
     */
    public static boolean replaceFile(String targetPath, String newSourcePath) {
        File targetFile = new File(targetPath);
        File sourceFile = new File(newSourcePath);

        if (!sourceFile.exists()) {
            return false;
        }

        // Create a safety backup of target before any overwrite
        if (targetFile.exists()) {
            SaveManager.createBackup(targetPath);
        }

        // Create temp file path
        String tempPath = targetPath + ".tmp";
        File tempFile = new File(tempPath);

        // Copy source file to temp location first
        if (!copyFile(sourceFile, tempFile)) {
            if (tempFile.exists()) {
                tempFile.delete();
            }
            return false;
        }

        // Perform the replacement
        if (targetFile.exists()) {
            if (!targetFile.delete()) {
                // If target deletion fails, clean temp and abort to avoid loss
                tempFile.delete();
                return false;
            }
        }

        // Rename temp to target
        boolean success = tempFile.renameTo(targetFile);
        if (!success) {
            // Attempt recovery from backup if it fails
            File backupFile = new File(targetPath + ".bak");
            if (backupFile.exists()) {
                backupFile.renameTo(targetFile);
            }
        }

        return success;
    }

    /**
     * Restores the save file from the latest safety backup (.bak) file.
     */
    public static boolean restoreFromBackup(String targetPath) {
        File targetFile = new File(targetPath);
        File backupFile = new File(targetPath + ".bak");

        if (!backupFile.exists()) {
            return false;
        }

        if (targetFile.exists()) {
            targetFile.delete();
        }

        return copyFile(backupFile, targetFile);
    }

    /**
     * Utility method to copy a file.
     */
    private static boolean copyFile(File src, File dest) {
        FileInputStream in = null;
        FileOutputStream out = null;
        try {
            in = new FileInputStream(src);
            out = new FileOutputStream(dest);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
            out.flush();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (in != null) in.close();
                if (out != null) out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
