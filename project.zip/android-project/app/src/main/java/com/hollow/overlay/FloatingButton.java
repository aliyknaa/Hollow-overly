package com.hollow.overlay;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

public class FloatingButton {

    private final Context context;
    private final WindowManager windowManager;
    private final OverlayView overlayView;
    private View bubbleView;
    private WindowManager.LayoutParams params;

    public FloatingButton(Context context, OverlayView overlayView) {
        this.context = context;
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        this.overlayView = overlayView;
        initializeView();
    }

    private void initializeView() {
        // Inflate layout
        bubbleView = LayoutInflater.from(context).inflate(R.layout.layout_floating_bubble, null);

        // Layout parameters for Overlay Button
        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES_O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 200;

        // Touch Listener for dragging and clicking
        ImageView icon = bubbleView.findViewById(R.id.imgBubbleIcon);
        icon.setOnTouchListener(new View.OnTouchListener() {
            private int lastAction;
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        lastAction = event.getAction();
                        return true;

                    case MotionEvent.ACTION_UP:
                        // If movement was minimal, consider it a click
                        if (lastAction == MotionEvent.ACTION_DOWN ||
                                (Math.abs(event.getRawX() - initialTouchX) < 10 &&
                                        Math.abs(event.getRawY() - initialTouchY) < 10)) {
                            toggleOverlay();
                        }
                        lastAction = event.getAction();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(bubbleView, params);
                        lastAction = event.getAction();
                        return true;
                }
                return false;
            }
        });
    }

    private void toggleOverlay() {
        if (overlayView.isVisible()) {
            overlayView.hide();
        } else {
            overlayView.show();
        }
    }

    public void show() {
        if (bubbleView.getParent() == null) {
            windowManager.addView(bubbleView, params);
        }
    }

    public void remove() {
        if (bubbleView != null && bubbleView.getParent() != null) {
            windowManager.removeView(bubbleView);
        }
    }
}
