package com.hollow.overlay;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

public class OverlayView {

    private final Context context;
    private final WindowManager windowManager;
    private View overlayView;
    private WindowManager.LayoutParams params;
    private boolean isVisible = false;

    // UI elements inside the floating editor
    private EditText editGeo;
    private EditText editHealth;
    private EditText editMaxHealth;
    private EditText editEssence;
    private CheckBox checkGodMode;
    private Button btnSave;
    private Button btnClose;

    public OverlayView(Context context) {
        this.context = context;
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        initializeView();
    }

    private void initializeView() {
        // Inflate the XML layout for the full editor overlay
        overlayView = LayoutInflater.from(context).inflate(R.layout.layout_overlay_editor, null);

        // Layout parameters. MATCH_PARENT to create a modal background effect,
        // but we clear FLAG_NOT_FOCUSABLE to allow keyboard typing.
        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES_O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, // allows focus and soft keyboard
                PixelFormat.TRANSLUCENT
        );

        // Bind UI Elements
        editGeo = overlayView.findViewById(R.id.editGeo);
        editHealth = overlayView.findViewById(R.id.editHealth);
        editMaxHealth = overlayView.findViewById(R.id.editMaxHealth);
        editEssence = overlayView.findViewById(R.id.editEssence);
        checkGodMode = overlayView.findViewById(R.id.checkGodMode);
        btnSave = overlayView.findViewById(R.id.btnSave);
        btnClose = overlayView.findViewById(R.id.btnClose);

        // Setup Buttons
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hide();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveChanges();
            }
        });
    }

    public boolean isVisible() {
        return isVisible;
    }

    public void show() {
        if (!isVisible) {
            loadSaveData();
            windowManager.addView(overlayView, params);
            isVisible = true;
        }
    }

    public void hide() {
        if (isVisible) {
            windowManager.removeView(overlayView);
            isVisible = false;
        }
    }

    public void remove() {
        hide();
    }

    /**
     * Reads and decrypts standard user1.dat save file, then populates edit fields.
     */
    private void loadSaveData() {
        try {
            JSONObject saveData = SaveManager.readSaveFile(context, 1);
            if (saveData != null) {
                // Read from playerData object inside the save file
                JSONObject playerData = saveData.has("playerData") ? saveData.getJSONObject("playerData") : saveData;

                editGeo.setText(String.valueOf(playerData.optInt("geo", 0)));
                editHealth.setText(String.valueOf(playerData.optInt("health", 5)));
                editMaxHealth.setText(String.valueOf(playerData.optInt("maxHealth", 5)));
                editEssence.setText(String.valueOf(playerData.optInt("dreamOrbs", 0)));
                checkGodMode.setChecked(playerData.optBoolean("infiniteEssence", false));
            } else {
                Toast.makeText(context, "No Save File found or Decryption failed.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "Error loading save: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Reads fields, patches the JSON structure, encrypts, and writes back.
     */
    private void saveChanges() {
        try {
            // Read values from form
            int geo = Integer.parseInt(editGeo.getText().toString().trim());
            int health = Integer.parseInt(editHealth.getText().toString().trim());
            int maxHealth = Integer.parseInt(editMaxHealth.getText().toString().trim());
            int essence = Integer.parseInt(editEssence.getText().toString().trim());
            boolean godMode = checkGodMode.isChecked();

            // Load original save
            JSONObject saveData = SaveManager.readSaveFile(context, 1);
            if (saveData == null) {
                saveData = new JSONObject(); // create new if none exists
            }

            JSONObject playerData = saveData.has("playerData") ? saveData.getJSONObject("playerData") : saveData;

            // Apply updates
            playerData.put("geo", geo);
            playerData.put("health", health);
            playerData.put("maxHealth", maxHealth);
            playerData.put("dreamOrbs", essence);
            playerData.put("infiniteEssence", godMode); // godmode flag

            if (saveData.has("playerData")) {
                saveData.put("playerData", playerData);
            }

            // Write back encrypted
            boolean success = SaveManager.writeSaveFile(context, 1, saveData);
            if (success) {
                Toast.makeText(context, "Save patched and encrypted successfully!", Toast.LENGTH_SHORT).show();
                hide();
            } else {
                Toast.makeText(context, "Failed to write save file.", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(context, "Please enter valid numeric values", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "Error saving: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
