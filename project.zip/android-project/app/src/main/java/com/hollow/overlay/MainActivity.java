package com.hollow.overlay;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_STORAGE = 101;
    private static final int PERMISSION_REQUEST_OVERLAY = 102;

    private TextView txtStatus;
    private TextView txtSavePath;
    private Button btnToggleService;
    private Button btnOpenSettings;

    private boolean isServiceRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtStatus = findViewById(R.id.txtStatus);
        txtSavePath = findViewById(R.id.txtSavePath);
        btnToggleService = findViewById(R.id.btnToggleService);
        btnOpenSettings = findViewById(R.id.btnOpenSettings);

        // Standard path on Android
        String targetPath = SaveManager.getSaveFilePath(this, 1);
        txtSavePath.setText("Save Path: " + targetPath);

        checkSaveFilePresence(targetPath);

        btnToggleService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkAllPermissions()) {
                    toggleOverlayService();
                } else {
                    requestPermissions();
                }
            }
        });

        btnOpenSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateServiceButtonState();
    }

    private void checkSaveFilePresence(String path) {
        File file = new File(path);
        if (file.exists()) {
            txtStatus.setText("Status: Hollow Knight Save File Detected!");
            txtStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        } else {
            txtStatus.setText("Status: Save File Not Detected at Default Path");
            txtStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
        }
    }

    private boolean checkAllPermissions() {
        boolean storagePermission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;

        boolean overlayPermission = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES_M) {
            overlayPermission = Settings.canDrawOverlays(this);
        }

        return storagePermission && overlayPermission;
    }

    private void requestPermissions() {
        // 1. Request Storage Permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_STORAGE);
        }

        // 2. Request Overlay Draw Permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES_M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, PERMISSION_REQUEST_OVERLAY);
                Toast.makeText(this, "Please enable Overlay Permission for HollowOverlay", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Storage permission granted!", Toast.LENGTH_SHORT).show();
                String targetPath = SaveManager.getSaveFilePath(this, 1);
                checkSaveFilePresence(targetPath);
            } else {
                Toast.makeText(this, "Storage permission denied! HollowOverlay cannot edit saves.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PERMISSION_REQUEST_OVERLAY) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES_M) {
                if (Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Overlay permission granted!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Overlay permission denied!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void toggleOverlayService() {
        Intent serviceIntent = new Intent(this, OverlayService.class);
        if (!isServiceRunning) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES_O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            isServiceRunning = true;
            btnToggleService.setText("Stop Overlay Service");
            btnToggleService.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
        } else {
            stopService(serviceIntent);
            isServiceRunning = false;
            btnToggleService.setText("Start Overlay Service");
            btnToggleService.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_blue_dark));
        }
    }

    private void updateServiceButtonState() {
        isServiceRunning = OverlayService.isRunning();
        if (isServiceRunning) {
            btnToggleService.setText("Stop Overlay Service");
            btnToggleService.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
        } else {
            btnToggleService.setText("Start Overlay Service");
            btnToggleService.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_blue_dark));
        }
    }
}
