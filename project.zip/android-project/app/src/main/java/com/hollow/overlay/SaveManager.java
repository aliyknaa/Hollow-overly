package com.hollow.overlay;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class SaveManager {

    private static final String PREFS_NAME = "HollowOverlayPrefs";
    private static final String KEY_SAVE_SLOT = "save_slot";
    private static final String DEFAULT_HK_PACKAGE = "com.TeamCherry.HollowKnight";

    /**
     * Gets the current save file path based on selected slot (1-4).
     */
    public static String getSaveFilePath(Context context, int slot) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int chosenSlot = prefs.getInt(KEY_SAVE_SLOT, slot);

        // Standard No-Root save path on Android 9:
        // /storage/emulated/0/Android/data/com.TeamCherry.HollowKnight/files/user1.dat
        File sdcard = Environment.getExternalStorageDirectory();
        return sdcard.getAbsolutePath() + "/Android/data/" + DEFAULT_HK_PACKAGE + "/files/user" + chosenSlot + ".dat";
    }

    /**
     * Backs up the save file safely prior to editing.
     */
    public static boolean createBackup(String filePath) {
        File src = new File(filePath);
        if (!src.exists()) {
            return false;
        }

        File dest = new File(filePath + ".bak");
        FileInputStream in = null;
        FileOutputStream out = null;

        try {
            in = new FileInputStream(src);
            out = new FileOutputStream(dest);

            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (in != null) in.close();
                if (out != null) out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Decrypts and reads the Hollow Knight save file.
     */
    public static JSONObject readSaveFile(Context context, int slot) {
        String path = getSaveFilePath(context, slot);
        File file = new File(path);
        if (!file.exists()) {
            return null;
        }

        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            byte[] fileBytes = new byte[(int) file.length()];
            int bytesRead = fis.read(fileBytes);

            if (bytesRead <= 0) {
                return null;
            }

            // Decrypt the bytes using our PatchEngine
            String decryptedJson = PatchEngine.decrypt(fileBytes);
            if (decryptedJson == null) {
                return null;
            }

            return new JSONObject(decryptedJson);

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Encrypts and writes changes back to the original save slot.
     */
    public static boolean writeSaveFile(Context context, int slot, JSONObject data) {
        String path = getSaveFilePath(context, slot);

        // 1. Create a safety backup first!
        createBackup(path);

        File file = new File(path);
        FileOutputStream fos = null;

        try {
            String jsonStr = data.toString();

            // Encrypt using PatchEngine
            byte[] encryptedBytes = PatchEngine.encrypt(jsonStr);
            if (encryptedBytes == null) {
                return false;
            }

            fos = new FileOutputStream(file);
            fos.write(encryptedBytes);
            fos.flush();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
