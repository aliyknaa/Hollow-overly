package com.hollow.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class OverlayService extends Service {

    private static final int NOTIFICATION_ID = 54321;
    private static final String CHANNEL_ID = "hollow_overlay_channel";
    private static boolean isServiceRunning = false;

    private FloatingButton floatingButton;
    private OverlayView overlayView;

    public static boolean isRunning() {
        return isServiceRunning;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        isServiceRunning = true;

        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildForegroundNotification());

        // Initialize UI components
        overlayView = new OverlayView(this);
        floatingButton = new FloatingButton(this, overlayView);

        // Show the initial floating bubble (collapsed button)
        floatingButton.show();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isServiceRunning = false;

        if (floatingButton != null) {
            floatingButton.remove();
        }
        if (overlayView != null) {
            overlayView.remove();
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES_O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "HollowOverlay Active Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Keeps the Hollow Knight in-game overlay active.");
            channel.enableLights(true);
            channel.setLightColor(Color.BLUE);
            channel.setShowBadge(false);

            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildForegroundNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                notificationIntent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES_M ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("HollowOverlay Running")
                .setContentText("Tap to open main controls. Overlay is active in-game.")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true);

        return builder.build();
    }
}
