package com.hollow.overlay;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class SettingsActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "HollowOverlayPrefs";
    private static final String KEY_SAVE_SLOT = "save_slot";

    private RadioGroup radioGroupSlots;
    private RadioButton radioSlot1, radioSlot2, radioSlot3, radioSlot4;
    private Button btnDeleteBackups;
    private Button btnSaveSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        radioGroupSlots = findViewById(R.id.radioGroupSlots);
        radioSlot1 = findViewById(R.id.radioSlot1);
        radioSlot2 = findViewById(R.id.radioSlot2);
        radioSlot3 = findViewById(R.id.radioSlot3);
        radioSlot4 = findViewById(R.id.radioSlot4);
        btnDeleteBackups = findViewById(R.id.btnDeleteBackups);
        btnSaveSettings = findViewById(R.id.btnSaveSettings);

        loadCurrentSettings();

        btnSaveSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });

        btnDeleteBackups.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearAllBackups();
            }
        });
    }

    private void loadCurrentSettings() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int slot = prefs.getInt(KEY_SAVE_SLOT, 1);

        switch (slot) {
            case 1: radioSlot1.setChecked(true); break;
            case 2: radioSlot2.setChecked(true); break;
            case 3: radioSlot3.setChecked(true); break;
            case 4: radioSlot4.setChecked(true); break;
        }
    }

    private void saveSettings() {
        int selectedId = radioGroupSlots.getCheckedRadioButtonId();
        int slot = 1;

        if (selectedId == R.id.radioSlot1) {
            slot = 1;
        } else if (selectedId == R.id.radioSlot2) {
            slot = 2;
        } else if (selectedId == R.id.radioSlot3) {
            slot = 3;
        } else if (selectedId == R.id.radioSlot4) {
            slot = 4;
        }

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_SAVE_SLOT, slot).apply();

        Toast.makeText(this, "Settings Saved. Selected Slot: " + slot, Toast.LENGTH_SHORT).show();
        finish();
    }

    private void clearAllBackups() {
        int deletedCount = 0;
        for (int i = 1; i <= 4; i++) {
            String path = SaveManager.getSaveFilePath(this, i) + ".bak";
            File backup = new File(path);
            if (backup.exists()) {
                if (backup.delete()) {
                    deletedCount++;
                }
            }
        }
        Toast.makeText(this, "Cleared " + deletedCount + " backup files.", Toast.LENGTH_SHORT).show();
    }
}
