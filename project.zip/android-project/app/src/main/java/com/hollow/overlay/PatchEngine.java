package com.hollow.overlay;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.spec.KeySpec;

public class PatchEngine {

    private static final String PASSWORD = "button";
    private static final byte[] SALT = new byte[] { 3, 5, 6, 7, 12, 3, 5, 10 };
    private static final int ITERATIONS = 1000;

    /**
     * Derives a 32-byte array sequentially from PBKDF2-HMAC-SHA1 and splits it
     * into a 16-byte AES-128 Key and a 16-byte IV.
     */
    private static DerivedKeyMaterial deriveKeyMaterial() throws Exception {
        // PBKDF2 with HMAC-SHA1 is the native implementation of .NET's Rfc2898DeriveBytes
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");

        // Requesting 256 bits (32 bytes) of derived cryptographic bits
        KeySpec spec = new PBEKeySpec(PASSWORD.toCharArray(), SALT, ITERATIONS, 256);
        byte[] derivedBytes = factory.generateSecret(spec).getEncoded();

        byte[] keyBytes = new byte[16];
        byte[] ivBytes = new byte[16];

        // First 16 bytes are the AES Key
        System.arraycopy(derivedBytes, 0, keyBytes, 0, 16);
        // Next 16 bytes are the CBC Initialization Vector (IV)
        System.arraycopy(derivedBytes, 16, ivBytes, 0, 16);

        return new DerivedKeyMaterial(keyBytes, ivBytes);
    }

    /**
     * Decrypts Hollow Knight save file ciphertext back to standard readable JSON.
     */
    public static String decrypt(byte[] ciphertext) {
        try {
            DerivedKeyMaterial material = deriveKeyMaterial();
            SecretKeySpec secretKey = new SecretKeySpec(material.key, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(material.iv);

            // PKCS5Padding in Java is functionally identical and compatible with PKCS7
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);

            byte[] decryptedBytes = cipher.doFinal(ciphertext);
            return new String(decryptedBytes, "UTF-8");

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Encrypts plain text JSON string into standard encrypted user1.dat bytes.
     */
    public static byte[] encrypt(String plaintext) {
        try {
            DerivedKeyMaterial material = deriveKeyMaterial();
            SecretKeySpec secretKey = new SecretKeySpec(material.key, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(material.iv);

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);

            return cipher.doFinal(plaintext.getBytes("UTF-8"));

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Helper structure to hold derived material.
     */
    private static class DerivedKeyMaterial {
        final byte[] key;
        final byte[] iv;

        DerivedKeyMaterial(byte[] key, byte[] iv) {
            this.key = key;
            this.iv = iv;
        }
    }
}
